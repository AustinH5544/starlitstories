﻿namespace Hackathon_2025.Models;

public class CheckoutRequest
{
    public string Email { get; set; } = "";
    public string Membership { get; set; } = "";
}