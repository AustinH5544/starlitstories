﻿namespace Hackathon_2025.Models;

public class OpenAISettings
{
    public required string ApiKey { get; set; }
}
