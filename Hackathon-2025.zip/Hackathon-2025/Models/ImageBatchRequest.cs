﻿namespace Hackathon_2025.Models;

public class ImageBatchRequest
{
    public required List<string> Prompts { get; set; }
}
