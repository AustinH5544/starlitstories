﻿namespace Hackathon_2025.Models;

public class AuthResponse
{
    public string Email { get; set; } = string.Empty;
    public string Membership { get; set; } = string.Empty;
}
