﻿namespace Hackathon_2025.Models;

public class StripeSettings
{
    public required string SecretKey { get; set; }
    public required string PublishableKey { get; set; }
}
